# FILE AIM CREATOR — Android project

Giao diện bám theo mockup đã mô tả và sử dụng logo `app/src/main/res/drawable-nodpi/logo.png` do người dùng cung cấp.

## Luồng
Splash → Nhập Key → Menu chính → Chọn Script → Chọn Extension → Chọn file → Nhập yêu cầu → Đang xử lý → Thành công → Lịch sử.

## Key
- 50 key BASIC — 30 ngày (30 ngày là mặc định vì yêu cầu không nêu thời hạn BASIC).
- 25 key PREMIUM — 50 ngày.
- 25 key PREMIUM — 306 ngày.
- Danh sách đầy đủ: `keys/ALL_KEYS.txt`.
- Trong app, màn hình kích hoạt chỉ có ô nhập key; không hiển thị sẵn key PREMIUM.
- Key hợp lệ mới mở Menu chính.

## Build APK
Mở thư mục này bằng Android Studio (AGP 8.5.2, compileSdk 35), sau đó Build → Generate App Bundle/APK → Generate APK.

Lưu ý: môi trường tạo file hiện tại không có Android SDK/Build Tools nên không thể đóng gói APK nhị phân trực tiếp trong phiên này. ZIP này là project Android hoàn chỉnh để build APK.
